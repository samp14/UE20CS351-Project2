# UE20CS351-CC-Mini_Project

Problem Statement: 
2. Microservice communication with RabbitMQ


Team Members:
Namrata N Keni   PES2UG20CS213
Nidhi Shetty     PES2UG20CS223
R Harshita       PES2UG20CS259

